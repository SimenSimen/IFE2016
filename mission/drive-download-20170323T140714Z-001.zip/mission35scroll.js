 (()=>{
 	elements = {
 		div : document.getElementById('lineNumber') ,
 		input : document.getElementById('input')
 	}
 	

 })();